import{j as r}from"./app-VKkwl0tG.js";import{C as t}from"./CartItems-GH_cBYhw.js";const a=()=>r.jsxs("div",{children:[r.jsx("h1",{children:"Shopping Cart"}),r.jsx(t,{})]});export{a as default};
