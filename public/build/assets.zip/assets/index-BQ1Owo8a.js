import{g as r,c as t}from"./app-VKkwl0tG.js";var a=t();const e=r(a);export{e as R,a as r};
